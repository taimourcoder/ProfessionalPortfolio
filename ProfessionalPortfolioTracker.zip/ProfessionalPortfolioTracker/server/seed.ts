import { db } from "./db";
import { projects, blogPosts } from "@shared/schema";

async function seedDatabase() {
  console.log("Seeding database...");

  // Sample projects data
  const sampleProjects = [
    {
      title: "E-Commerce Dashboard",
      description: "A comprehensive analytics dashboard for online retailers with real-time data visualization and inventory management.",
      imageUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      category: "web",
      technologies: ["React", "Node.js", "MongoDB"],
      liveUrl: "https://demo.example.com",
      githubUrl: "https://github.com/taimoursultan/ecommerce-dashboard",
      featured: true
    },
    {
      title: "Fitness Tracking App",
      description: "A cross-platform mobile app for tracking workouts, nutrition, and health metrics with social features.",
      imageUrl: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      category: "mobile",
      technologies: ["React Native", "Firebase", "Redux"],
      liveUrl: "https://app.example.com",
      githubUrl: "https://github.com/taimoursultan/fitness-app",
      featured: true
    },
    {
      title: "Task Management Platform",
      description: "A collaborative project management tool with real-time updates, team collaboration features, and advanced analytics.",
      imageUrl: "https://images.unsplash.com/photo-1547658719-da2b51169166?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      category: "web",
      technologies: ["Vue.js", "Laravel", "PostgreSQL"],
      liveUrl: "https://tasks.example.com",
      githubUrl: "https://github.com/taimoursultan/task-platform",
      featured: true
    },
    {
      title: "Brand Identity Design",
      description: "Complete brand identity package including logo design, color palette, typography, and brand guidelines for a tech startup.",
      imageUrl: "https://images.unsplash.com/photo-1559028006-448665bd7c7f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      category: "design",
      technologies: ["Figma", "Illustrator", "Photoshop"],
      liveUrl: "https://brand.example.com",
      githubUrl: null,
      featured: false
    },
    {
      title: "Analytics Dashboard",
      description: "Interactive data visualization platform for business intelligence with custom charts and real-time data processing.",
      imageUrl: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      category: "web",
      technologies: ["D3.js", "Python", "AWS"],
      liveUrl: "https://analytics.example.com",
      githubUrl: "https://github.com/taimoursultan/analytics-dashboard",
      featured: false
    },
    {
      title: "UI/UX Case Study",
      description: "Complete user experience redesign for a financial services app, focusing on accessibility and user-centered design principles.",
      imageUrl: "https://images.unsplash.com/photo-1561736778-92e52a7769ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      category: "design",
      technologies: ["Figma", "Principle", "User Research"],
      liveUrl: "https://case-study.example.com",
      githubUrl: null,
      featured: false
    }
  ];

  // Sample blog posts data
  const sampleBlogPosts = [
    {
      title: "Building Scalable React Applications",
      excerpt: "Learn best practices for structuring large React applications with proper state management and component architecture.",
      content: "Full article content here...",
      imageUrl: "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      category: "Development",
      publishedAt: new Date("2023-12-15"),
      readTime: 8
    },
    {
      title: "The Future of Web Design",
      excerpt: "Exploring emerging trends in web design and how they're shaping the future of digital experiences.",
      content: "Full article content here...",
      imageUrl: "https://images.unsplash.com/photo-1522542550221-31fd19575a2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      category: "Design",
      publishedAt: new Date("2023-12-10"),
      readTime: 6
    },
    {
      title: "Optimizing Web Performance",
      excerpt: "Essential techniques for improving web application performance and user experience through optimization strategies.",
      content: "Full article content here...",
      imageUrl: "https://images.unsplash.com/photo-1504639725590-34d0984388bd?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
      category: "Performance",
      publishedAt: new Date("2023-12-05"),
      readTime: 10
    }
  ];

  try {
    // Clear existing data
    await db.delete(projects);
    await db.delete(blogPosts);

    // Insert projects
    await db.insert(projects).values(sampleProjects);
    console.log("✓ Inserted sample projects");

    // Insert blog posts
    await db.insert(blogPosts).values(sampleBlogPosts);
    console.log("✓ Inserted sample blog posts");

    console.log("Database seeding completed successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

// Run the seed function
seedDatabase();