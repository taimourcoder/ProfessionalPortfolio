export const SKILLS = {
  frontend: [
    { name: "React/Next.js", level: 95 },
    { name: "Vue.js", level: 88 },
    { name: "TypeScript", level: 92 },
  ],
  backend: [
    { name: "Node.js", level: 90 },
    { name: "Python/Django", level: 85 },
    { name: "PostgreSQL", level: 82 },
  ],
  design: [
    { name: "UI/UX Design", level: 88 },
    { name: "Figma", level: 93 },
    { name: "Adobe Creative Suite", level: 80 },
  ],
};

export const SERVICES = [
  {
    title: "Web Development",
    description: "Custom web applications built with modern frameworks and best practices for performance and scalability.",
    icon: "laptop-code",
    price: "Starting at $2,500",
    features: ["Responsive Design", "API Integration", "Performance Optimization"],
    color: "bg-portfolio-primary",
  },
  {
    title: "Mobile Development",
    description: "Cross-platform mobile applications that provide native-like performance and user experience.",
    icon: "mobile-alt",
    price: "Starting at $3,500",
    features: ["iOS & Android", "React Native", "App Store Deployment"],
    color: "bg-portfolio-secondary",
  },
  {
    title: "UI/UX Design",
    description: "User-centered design solutions that create intuitive and engaging digital experiences.",
    icon: "paint-brush",
    price: "Starting at $1,800",
    features: ["User Research", "Wireframing & Prototyping", "Design Systems"],
    color: "bg-portfolio-accent",
  },
];

export const NAVIGATION_LINKS = [
  { href: "#home", label: "Home" },
  { href: "#about", label: "About" },
  { href: "#skills", label: "Skills" },
  { href: "#projects", label: "Projects" },
  { href: "#services", label: "Services" },
  { href: "#blog", label: "Blog" },
  { href: "#contact", label: "Contact" },
];

export const SOCIAL_LINKS = [
  { href: "https://linkedin.com/in/taimoursultan", icon: "linkedin", label: "LinkedIn" },
  { href: "https://github.com/taimoursultan", icon: "github", label: "GitHub" },
  { href: "https://twitter.com/taimoursultan", icon: "twitter", label: "Twitter" },
  { href: "https://dribbble.com/taimoursultan", icon: "dribbble", label: "Dribbble" },
];

export const CONTACT_INFO = {
  email: "taimour@example.com",
  phone: "+1 (555) 123-4567",
  location: "San Francisco, CA",
};
