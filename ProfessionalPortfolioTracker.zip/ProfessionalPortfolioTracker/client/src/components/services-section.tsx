import { motion } from "framer-motion";
import { LucideIcon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, Laptop, Smartphone, Palette } from "lucide-react";
import { SERVICES } from "@/lib/constants";

const iconMap: Record<string, LucideIcon> = {
  "laptop-code": Laptop,
  "mobile-alt": Smartphone,
  "paint-brush": Palette,
};

export function ServicesSection() {
  return (
    <section id="services" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="bg-portfolio-dark px-6 py-3 rounded-lg inline-block mb-4">
            <h2 className="text-4xl font-bold text-white font-serif">
              Services
            </h2>
          </div>
          <p className="text-lg text-muted-foreground">
            How I can help bring your ideas to life
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {SERVICES.map((service, index) => {
            const Icon = iconMap[service.icon];
            return (
              <motion.div
                key={service.title}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <Card className="text-center hover:shadow-xl transition-shadow h-full">
                  <CardContent className="p-8">
                    <div
                      className={`w-16 h-16 ${service.color} rounded-full flex items-center justify-center mx-auto mb-6`}
                    >
                      <Icon className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold mb-4">
                      {service.title}
                    </h3>
                    <p className="text-muted-foreground mb-6">
                      {service.description}
                    </p>
                    <ul className="text-left space-y-2 mb-6">
                      {service.features.map((feature) => (
                        <li key={feature} className="flex items-center gap-2">
                          <Check className="h-4 w-4 text-portfolio-success" />
                          <span className="text-sm">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <Badge
                      variant="outline"
                      className="text-lg font-bold py-2 px-4"
                    >
                      {service.price}
                    </Badge>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
