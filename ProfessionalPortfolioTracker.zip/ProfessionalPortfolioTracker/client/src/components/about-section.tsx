import { motion } from "framer-motion";
import { MapPin, Mail, Phone, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CONTACT_INFO } from "@/lib/constants";
import profileImage from "@assets/A_1752231398746.jfif";

export function AboutSection() {
  return (
    <section id="about" className="py-20 bg-muted/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <div className="bg-portfolio-dark px-6 py-3 rounded-lg inline-block mb-6">
              <h2 className="text-4xl font-bold text-white font-serif">
                About Me
              </h2>
            </div>
            <p className="text-lg mb-6 text-muted-foreground">
              I'm a passionate full-stack developer and creative designer with
              over 5 years of experience in crafting digital solutions. My
              journey began with a curiosity for how things work, which led me
              to explore the intersection of technology and creativity.
            </p>
            <p className="text-lg mb-8 text-muted-foreground">
              I specialize in creating user-centric applications that not only
              function flawlessly but also provide memorable experiences. When
              I'm not coding, you'll find me exploring new design trends,
              contributing to open-source projects, or capturing the world
              through my camera lens.
            </p>
            <div className="flex flex-wrap gap-4 mb-8">
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 text-portfolio-dark" />
                <span>{CONTACT_INFO.location}</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-portfolio-dark" />
                <span>{CONTACT_INFO.email}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-portfolio-dark" />
                <span>{CONTACT_INFO.phone}</span>
              </div>
            </div>
            <Button 
              className="bg-portfolio-dark hover:bg-portfolio-dark/90 text-white"
              onClick={() => {
                const link = document.createElement('a');
                link.href = '/resume.pdf';
                link.download = 'Taimour_Sultan_Resume.pdf';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
              }}
            >
              <Download className="mr-2 h-4 w-4" />
              Download Resume
            </Button>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <div className="relative">
              <img
                src={profileImage}
                alt="Taimour Sultan - Professional developer portrait"
                className="rounded-2xl shadow-2xl w-full h-auto max-w-lg mx-auto object-cover"
                style={{
                  imageRendering: 'crisp-edges',
                  imageRendering: '-webkit-optimize-contrast',
                  imageRendering: 'optimize-contrast',
                  msInterpolationMode: 'bicubic'
                }}
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-portfolio-dark/10 to-transparent rounded-2xl"></div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
