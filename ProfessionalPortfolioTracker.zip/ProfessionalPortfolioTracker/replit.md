# Portfolio Website - Replit Development Guide

## Overview

This is a modern full-stack portfolio website built with React, TypeScript, and Express.js. The application features a responsive design with a clean, professional interface showcasing projects, skills, blog posts, and contact information.

## User Preferences

Preferred communication style: Simple, everyday language.
Portfolio owner: Taimour Sultan (updated from Alex.Dev)
Database: PostgreSQL with full data persistence enabled

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Animations**: Framer Motion for smooth transitions and interactions
- **Theme**: Light/dark mode support with custom theme provider

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon Database (serverless PostgreSQL)
- **API Design**: RESTful API with JSON responses
- **Development**: Hot reload with Vite middleware integration

### Key Design Decisions

1. **Monorepo Structure**: Shared schema between client and server in `/shared` directory
2. **Type Safety**: Full TypeScript coverage with shared types and Zod validation
3. **Component Architecture**: Modular UI components with consistent design system
4. **Database Schema**: Normalized tables for users, projects, blog posts, and contact messages
5. **Development Experience**: Integrated Vite development server with Express backend

## Key Components

### Database Schema (`/shared/schema.ts`)
- **Users**: Authentication and user management
- **Projects**: Portfolio project showcase with categories and technologies
- **Blog Posts**: Content management with categories and metadata
- **Contact Messages**: Contact form submissions

### API Routes (`/server/routes.ts`)
- GET `/api/projects` - Fetch all projects
- GET `/api/projects/featured` - Fetch featured projects
- GET `/api/projects/category/:category` - Filter projects by category
- GET `/api/blog` - Fetch all blog posts
- GET `/api/blog/latest` - Fetch recent blog posts
- POST `/api/contact` - Submit contact form

### Storage Layer (`/server/storage.ts`)
- Interface-based storage abstraction
- DatabaseStorage implementation using PostgreSQL
- Full CRUD operations for all entities
- Replaced MemStorage with database persistence

### Frontend Pages
- **Home**: Single-page application with multiple sections
- **Hero Section**: Landing area with call-to-action
- **About Section**: Personal information and contact details
- **Skills Section**: Technical skills with progress indicators
- **Projects Section**: Portfolio showcase with filtering
- **Services Section**: Service offerings
- **Blog Section**: Latest articles preview
- **Contact Section**: Contact form with validation

## Data Flow

1. **Client Requests**: React components use TanStack Query for data fetching
2. **API Layer**: Express.js handles HTTP requests and responses
3. **Storage Layer**: Interface-based storage handles data persistence
4. **Database**: PostgreSQL with Drizzle ORM for type-safe queries
5. **Validation**: Zod schemas ensure data integrity across client and server

## External Dependencies

### Frontend Dependencies
- React ecosystem (React, React DOM, React Router alternative)
- UI libraries (Radix UI, shadcn/ui, Tailwind CSS)
- Animation library (Framer Motion)
- Form handling (React Hook Form, Hookform Resolvers)
- State management (TanStack Query)
- Utility libraries (clsx, class-variance-authority, date-fns)

### Backend Dependencies
- Express.js framework
- Database tools (Drizzle ORM, Neon Database client)
- PostgreSQL database with full persistence
- Validation (Zod)
- Development tools (tsx, esbuild for production builds)

### Development Tools
- Vite for build tooling and development server
- TypeScript for type safety
- ESLint and Prettier for code quality
- PostCSS for CSS processing

## Deployment Strategy

### Development Mode
- Vite development server integrated with Express backend
- Hot module replacement for frontend changes
- Automatic TypeScript compilation
- Database migrations with Drizzle Kit

### Production Build
- Frontend: Vite builds optimized static assets
- Backend: esbuild bundles server code for Node.js
- Database: PostgreSQL hosted on Neon Database
- Environment: Configured for production deployment

### Environment Configuration
- `DATABASE_URL` environment variable for database connection
- Development and production build scripts
- Type checking and database schema validation

The application uses a modern development stack with emphasis on type safety, developer experience, and maintainable architecture. The shared schema approach ensures consistency between frontend and backend, while the modular component structure allows for easy maintenance and feature additions.

## Recent Changes

### Database Integration (January 2025)
- Added PostgreSQL database with Drizzle ORM
- Created database connection and schema management
- Replaced in-memory storage with persistent database storage
- Seeded database with sample projects and blog posts
- All data now persists between application restarts

### Personal Branding Update
- Updated portfolio from "Alex.Dev" to "Taimour Sultan"
- Changed contact information and social links
- Updated all branding across navigation, footer, and metadata